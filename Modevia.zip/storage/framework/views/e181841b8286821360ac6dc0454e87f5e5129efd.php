<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/x-icon" href="./assets/images/fav.png">
    <title>Edu Digit</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="./assets/css/style-rtl.css">
    <link rel="stylesheet" href="./assets/css/responsive.css">
    <link href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css" rel="stylesheet" />
    <style>
        /*.dataTables_paginate{*/
        /*    display: none;*/
        /*}*/
    </style>
</head>

<body>
<div class="loader" id="loader">
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
</div>
<main>
    <div class="response">
        <div id="particles" class="particles"></div>
        <svg class="bg-shape" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1205.46 968.93">
            <path d="M1212.38,50.21l-86,684.35a35,35,0,0,1-25.1,29.31l-749,214.52a35,35,0,0,1-42.72-22.14L9.18,94.48A35,35,0,0,1,41.11,47.94l1135.38-37.1A35,35,0,0,1,1212.38,50.21Z" transform="translate(-7.2 -10.82)" />
        </svg>
        <div class="container-fluid z-10">
            <div class="row">
                <div class="col-md-1 d-flex flex-column align-items-center">
                    <img src="./assets/images/edulogo-3.png" alt="img">
                    <button class="menu-btn mt-5 mb-auto"><img src="./assets/images/menu.svg" alt="img"></button>
                    <a href="<?php echo e(route('logout')); ?>" class="logout-btn "><img src="./assets/images/logout.svg" alt="img"></a>
                </div>
                <div class="col-md-11">
                    <div class="table-container p-5">
                        <div class="row ">
                            <div class="col-lg-9 mb-4">
                                <div class="form-group search">
                                    <input type="text" class="filter-data" placeholder="بحث">
                                    <button>
                                        <svg width="20" viewBox="0 0 256 256">
                                            <path fill="#a2a3a4" d="m229.7 218.3l-43.3-43.2a92.2 92.2 0 1 0-11.3 11.3l43.2 43.3a8.2 8.2 0 0 0 11.4 0a8.1 8.1 0 0 0 0-11.4ZM40 116a76 76 0 1 1 76 76a76.1 76.1 0 0 1-76-76Z" />
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <div class="col-lg-3 mb-4">
                                <div class=" d-flex align-items-center justify-content-end gap-20">
                                    <a href="<?php echo e(url()->current()); ?>?change_language=en" class="d-flex align-items-center gap-10 text-dark"><img src="./assets/images/usa.svg" alt="img" class="width-30"> EN </a>
                                    <div class="uktra-btn">
                                        <img src="/assets/images/uktralogo-2.png" alt="">
                                        <h6 class="m-0">uktra</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-4">
                                <h3>بيانات المستخدمين</h3>
                            </div>
                            <div class="col-6 text-end mb-4">
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle btn-style-2" type="button" data-bs-toggle="dropdown" aria-expanded="false"> تحميل </button>
                                    <ul class="dropdown-menu p-0">
                                        <li>
                                            <a class="dropdown-item d-flex justify-content-between align-items-center px-3 py-2 export-pdf" href="#"> PDF <img src="./assets/images/pdf.svg" alt="img" class="width-25">
                                            </a>
                                        </li>
                                        <li><a class="dropdown-item d-flex justify-content-between align-items-center px-3 py-2 export-excel" href="#"> excel <img src="./assets/images/excel.svg" alt="img" class="width-25">
                                            </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class=" col-6 col-lg-2 mb-4">
                                <div class="form-group">
                                    <input type="date" class="date style-2">
                                </div>
                            </div>
                            <div class="col-6 col-lg-2 mb-4">
                                <div class="form-group">
                                    <input type="text" placeholder="الوظيفة" class="position style-2">
                                </div>
                            </div>
                            <div class="col-6 col-lg-2 mb-4"> <select class="form-select style-2 gov">
                                    <option selected value="">المحافظة</option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city['governorate_name_en']); ?>"><?php echo e($city['governorate_name_en']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select></div>
                            <div class="col-6 col-lg-2 mb-4"> <select class="form-select style-2 how_you_heard_about_us">
                                    <option selected value=""> سمعت عنا</option>
                                    <option value="Google Search">Google Search</option>
                                    <option value="Facebook">Facebook</option>
                                    <option value="Instagram">Instagram</option>
                                    <option value="Youtube">Youtube</option>
                                    <option value="Recommended by Friends">Recommended by Friends</option>
                                    <option value="Others">Others</option>
                                </select></div>
                            <div class=" col-6 col-lg-2 mb-4 text-end">
                                <button class="btn-style-1 border-none filter-btn"> فلتر <svg width="24" height="22" viewBox="0 0 24 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#mdvoy9euxa)">
                                            <path d="M10 16.5h4v-1.833h-4V16.5zm-7-11v1.833h18V5.5H3zm3 6.417h12v-1.834H6v1.834z" fill="currentcolor" />
                                        </g>
                                        <defs>
                                            <clipPath id="mdvoy9euxa">
                                                <path fill="currentcolor" transform="rotate(90 12 12)" d="M0 0h22v24H0z" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="table-responsive max-h-400">
                            <table class="table min-w-1000 " id="kt_datatable">
                                <thead>
                                <tr>
                                    <th scope="col">اليوم و التاريخ</th>
                                    <th scope="col">الاسم</th>
                                    <th scope="col">البريد الإلكتروني</th>
                                    <th scope="col">رقم الهاتف</th>
                                    <th scope="col">إسم المدرسة</th>
                                    <th scope="col">الوظيفة</th>
                                    <th scope="col">المحافظة</th>
                                    <th scope="col">سمعت عنا</th>
                                    <th scope="col">action</th>
                                </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                        <div aria-label="Page navigation example">
                            <ul class="pagination justify-content-center m-0">
                                <li class="page-item"><a class="page-link d-flex align-items-center gap-10 previous" href="#">
                                        <svg width="18" viewBox="0 0 256 256" class="arrow-rtl">
                                            <path fill="currentColor"
                                                  d="M224 128a8 8 0 0 1-8 8H59.3l58.4 58.3a8.1 8.1 0 0 1 0 11.4a8.2 8.2 0 0 1-11.4 0l-72-72a8.1 8.1 0 0 1 0-11.4l72-72a8.1 8.1 0 0 1 11.4 11.4L59.3 120H216a8 8 0 0 1 8 8Z" />
                                        </svg> السابق</a></li>
                                <li class="pg-num">

                                </li>
                                <li class="page-item"><a class="page-link d-flex align-items-center gap-10 next" href="#">التالي <svg class="arrow-rtl" width="18" viewBox="0 0 256 256">
                                            <path fill="currentColor" d="m220.2 132.2l-72 72a5.9 5.9 0 0 1-8.4-8.4l61.7-61.8H40a6 6 0 0 1 0-12h161.5l-61.7-61.8a5.9 5.9 0 0 1 8.4-8.4l72 72a5.8 5.8 0 0 1 0 8.4Z" />
                                        </svg>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12">
                    <div class="copyrights ">
                        <span class="text-white"> powered by</span> <a href="#" target="_blank"><img src="./assets/images/uktralogo.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<button class="to-top">
    <img src="./assets/images/scroll.gif" alt="">
</button>
<script src="./assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/particles.min.js"></script>
<script src="./assets/js/main.js"></script>





<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
<link href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css" rel="stylesheet" />

<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src ="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
<script src ="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>

<script>
    let languages = {
        'ar': 'https://cdn.datatables.net/plug-ins/1.10.19/i18n/Arabic.json',
        'en': 'https://cdn.datatables.net/plug-ins/1.10.19/i18n/English.json'
    };
    var table = $('#kt_datatable').DataTable({
        responsive: true,
        paging:   true,
        ordering: false,
        info:     false,
        filter:     false,
        pagingType:"full_numbers",
        language: {
            url: languages['<?php echo e(app()->getLocale()); ?>']
        },
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('users')); ?>" ,
            type: 'GET',
            data: function (d) {
                d.search = $('.filter-data').val(),
                d.date = $('.date').val(),
                d.position = $('.position').val()
                d.gov = $('.gov').val()
                d.how_you_heard_about_us = $('.how_you_heard_about_us').val()
            },
        },
        columns: [
            {data: 'created_at', name: 'created_at'},
            {data: 'name', name: 'name'},
            {data: 'email', name: 'email'},
            {data: 'phone', name: 'phone'},
            {data: 'school_name', name: 'school_name'},
            {data: 'position', name: 'position'},
            {data: 'government', name: 'government'},
            {data: 'how_you_heard_about_us', name: 'how_you_heard_about_us'},
            {data: 'actions', name: 'actions'},
        ],

    });
    setTimeout(function (){
        pg()
    },1000)

    function pg(){
        // row =``;
        // currentPage = table.page.info().page;
        // currentPageNumber = table.page.info().page+1;
        // all_pages = table.page.info().pages;

        // $('.pg-num').empty();

        // if(all_pages > page-1) {

            // row += `<li class="page-item">
            //         <a class="page-link page-reload" data-page="${currentPage}" >${currentPageNumber}</a>
            //     </li>`;
        // }

        // if(all_pages > currentPage+1){
        //     row += `<li class="page-item">
        //             <a class="page-link page-reload" data-page="${currentPage+1}" >${currentPageNumber+1}</a>
        //         </li>`;
        // }

        // if(all_pages > currentPage+2){
        //     row += `<li class="page-item">
        //             <a class="page-link page-reload" data-page="${currentPage+2}" >${currentPageNumber+2}</a>
        //         </li>`;
        // }


        // $('.pg-num').html(row)
    }

    $(document).on('click','.page-reload', function() {
        table.page($(this).data('page')).draw('page');
        pg()
    });

    $('.next').on('click', function() {
        table.page('next').draw('page');
        pg()
    });

    $('.previous').on('click', function() {
        table.page('previous').draw('page');
        pg()
    });

    $('.filter-data , .date , .position').on('keyup', function() {
        table.ajax.reload();
    });

    $('.gov , .how_you_heard_about_us').on('change', function() {
        table.ajax.reload();
    });

    $('.filter-btn').on('click', function() {
        table.ajax.reload();
    });

    $('.export-pdf').on('click', function() {
        search = $('.filter-data').val()
        date = $('.date').val()
        position = $('.position').val()
        gov = $('.gov').val()
        how_you_heard_about_us = $('.how_you_heard_about_us').val()
        window.open('<?php echo e(route('export-pdf')); ?>?search='+search+'&date='+date+'&position='+position+'&gov='+gov+'&how_you_heard_about_us='+how_you_heard_about_us, '_blank')
    });

    $('.export-excel').on('click', function() {
        search = $('.filter-data').val()
        date = $('.date').val()
        position = $('.position').val()
        gov = $('.gov').val()
        how_you_heard_about_us = $('.how_you_heard_about_us').val()
        window.open('<?php echo e(route('export')); ?>?search='+search+'&date='+date+'&position='+position+'&gov='+gov+'&how_you_heard_about_us='+how_you_heard_about_us, '_blank')
    });

</script>


</body>

</html>
<?php /**PATH F:\edu_digit\resources\views/users_ar.blade.php ENDPATH**/ ?>