<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/x-icon" href="./assets/images/fav.png">
    <title>Edu Digit</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href="./assets/css/responsive.css">
    <style>

        .hero-section{
            background-image: url('./assets/images/background.png');
            background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
        }

        .hero-h1{
            margin: auto;
        }

    </style>
</head>

<body>
<div class="loader" id="loader">
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
</div>
<nav>
    <div class="container">
        <div class="row">
            <div class="col-4 col-md-6 col-lg-4"> <a href="index.html"><img src="./assets/images/edulogo-1.png" alt="img" class="logo"></a></div>
            <div class="col-md-6 col-lg-4 d-none d-lg-block">
                <div class="d-flex h-100 justify-content-evenly align-items-center">
                    <a href="#hero">home</a>
                    <a href="#about">why</a>
                    <a href="#module">modules</a>
                    <a href="#footer">contact</a>
                </div>
            </div>
            <div class="col-8 col-md-6 col-lg-4">
                <div class="d-flex justify-content-end align-items-center h-100 gap-20">
                    <a href="<?php echo e(url()->current()); ?>?change_language=ar" class="d-flex align-items-center gap-10"><img src="./assets/images/ksa.svg" alt="img" class="width-30"> AR </a>
                    <a href="#appointment" class="btn-style-2 "> request appointment <svg width="22" viewBox="0 0 256 256">
                            <path fill="currentColor" d="m221.7 133.7l-72 72a8.2 8.2 0 0 1-11.4 0a8.1 8.1 0 0 1 0-11.4l58.4-58.3H40a8 8 0 0 1 0-16h156.7l-58.4-58.3a8.1 8.1 0 0 1 11.4-11.4l72 72a8.1 8.1 0 0 1 0 11.4Z" />
                        </svg></a>
                </div>
            </div>
        </div>
    </div>
</nav>
<main>
    <div class="hero-section" id="hero" style="">
        <div id="particles" class="particles"></div>



        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="text-center hero-h1"> one  automated  smart  solution</h1>
                    <br>
                    <a href="#appointment" class="btn-style-1 ">request appointment</a>
                </div>



            </div>
        </div>
    </div>
    <div class="about" id="about">
        <span class="stroke-text">why</span>
        <div class="container">
            <div class="row">
                <div class="col-md-6 z-10">
                    <h2 class="text-white">the best success partner</h2>
                    <p> We deeply understand the school market with the analytical skills of our experts , who study all the market insights to offer you the most effective system that fulfills what you exactly need to achieve
                        your goal Edu-digit supports you in planning and executing and we go for an extra step with you through professional maintenance and consultancy </p>
                    <p> We don't just offer the system you expect we offer your school the system it needs that covers each detail we facilitate every process and we enhance the school's performance overall </p>
                </div>
                <div class="col-md-6">
                    <ul class="about-list">
                        <li>the most reasonable pricing plans.</li>
                        <li>the most cost-effective system.</li>
                        <li>presentation meeting to illustrate</li>
                        <li>features and functions of the system</li>
                        <li>on-ground training to help your crew to work effectively on</li>
                        <li>dedicated maintenance to solve any possible issues</li>
                        <li>recommendations to stay up to date with market needs</li>
                        <li>the expert point of view to help you take important decisions </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="modules" id="module">
        <div id="particles2" class="particles"></div>
        <div class="container">
            <div class="col-12 mb-5">
                <h2>system modules</h2>
                <div class="col-md-6 col-lg-4">
                    <p> School Management System Modules and Their Functionality One-System, Fast and Smart School Management </p>
                </div>
            </div>
            <div class="row g-3 g-md-4">
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Front Office.svg" alt="">
                        <h5>Front Office</h5>
                        <p>for inquiries, calls, visitors, postal receive and dispatch</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Student Affairs.svg" alt="">
                        <h5>Student Affairs</h5>
                        <p>for information like student profile, admission, history, attendance and attendance report</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Fees Collection.svg" alt="">
                        <h5>Fees Collection</h5>
                        <p>for all the details related to student fees collection, fees master creation, fees dues and fees report</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Finance.svg" alt="">
                        <h5>Finance</h5>
                        <p>for income, expenses , Banking and Safe Management, General Ledger, profit and loss reports</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Examinations.svg" alt="">
                        <h5>Examinations</h5>
                        <p>for creating exams, scheduling exam, exam marks entry and marks grade</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Material Hub.svg" alt="">
                        <h5>Material Hub</h5>
                        <p>for managing subject status, lesson plan and assignments study material</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Online Portal.svg" alt="">
                        <h5>Online Portal</h5>
                        <p>for online exams, Zoom live G-meet live classes for students</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Academics.svg" alt="">
                        <h5>Academics</h5>
                        <p>for classes, subjects, assign teachers, timetable and promote students to the upper class.</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Human Resource.svg" alt="">
                        <h5>Human Resource</h5>
                        <p>for staff members management: search, profile, attendance, payroll and leaves</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Communicate.svg" alt="">
                        <h5>Communicate</h5>
                        <p>for notice board with a messaging system to students, parents and teachers</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Library.svg" alt="">
                        <h5>Library</h5>
                        <p>all the books in your library, can be managed here</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Inventory.svg" alt="">
                        <h5>Inventory</h5>
                        <p>manage all the assets of your school with stocks and store them under the inventory module</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Transport.svg" alt="">
                        <h5>Transport</h5>
                        <p>for managing transportation services like routes and their fares</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Hostel.svg" alt="">
                        <h5>Hostel</h5>
                        <p>For managing hostels, hostel rooms And their fares</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Certificate.svg" alt="">
                        <h5>Certificate</h5>
                        <p>Design and generate student certificate and ID Card here</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Front CMS.svg" alt="">
                        <h5>Front CMS</h5>
                        <p>site management: creating pages, menus, events, a gallery and news</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Reports.svg" alt="">
                        <h5>Reports</h5>
                        <p>all the various reports related to different modules can be found here</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/System Settings.svg" alt="">
                        <h5>System Settings</h5>
                        <p>configuration like school sessions, Payment, backup, languages and custom fields</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Calendar & to-do List.svg" alt="">
                        <h5>Calendar & to-do List</h5>
                        <p>track and manage periodic activities and create task in the to-do list</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Chat.svg" alt="">
                        <h5>Chat</h5>
                        <p>chat for two-way messaging staff and students</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="appointment" id="appointment">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 text-white text-center">
                    <h2 class="text-white">request appointment</h2>
                    <p>Submit your contact info below, and we’ll get in touch ASAP</p>
                </div>
                <div class="col-md-8 col-lg-6">

                    <form method="post" action="<?php echo e(route('store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">name *</label>
                                    <input type="text" name="name" placeholder="name" id="" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">email</label>
                                    <input type="email" name="email" placeholder="email" id="">
                                    <?php if($errors->has('email')): ?>
                                        <p style="color:red;" class="error"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">phone *</label>
                                    <input type="text" name="phone" placeholder="phone" id="" required>
                                    <?php if($errors->has('phone')): ?>
                                        <p style="color:red;" class="error"><?php echo e($errors->first('phone')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">government</label>
                                    <select name="government" id="">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city['governorate_name_en']); ?>"><?php echo e($city['governorate_name_en']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">position </label>
                                    <input name="position" type="text" placeholder="position" id="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">school name </label>
                                    <input name="school_name" type="text" placeholder="school name" id="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="">how you heard about us </label>
                                    <select name="how_you_heard_about_us" id="">
                                        <option value="">How You Heard About Us</option>
                                        <option value="Google Search">Google Search</option>
                                        <option value="Facebook">Facebook</option>
                                        <option value="Instagram">Instagram</option>
                                        <option value="Youtube">Youtube</option>
                                        <option value="Recommended by Friends">Recommended by Friends</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit">submit</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</main>
<footer id="footer">
    <div class="container">
        <div class="row justify-content-center">
            <div class=" col-lg-10">
                <div class="footer-content">
                    <img src="./assets/images/edulogo-2.png" alt="logo" class="footer-logo">
                    <div>
                        <h5 class="mb-4 mt-3 mt-md-0">get in touch</h5>
                        <div class="d-flex align-items-center gap-20 flex-wrap">
                            <div class="d-flex align-items-center gap-10">
                                <svg width="32" height="32" viewBox="0 0 256 256">
                                    <path fill="var(--color2)"
                                          d="M176 224C96.6 224 32 159.4 32 80a56.2 56.2 0 0 1 48.9-55.6A16.3 16.3 0 0 1 97.6 34l20.1 46.9a15.9 15.9 0 0 1-1.4 15.1l-16.6 25.4a76.5 76.5 0 0 0 35.2 35l25.1-16.7a15.6 15.6 0 0 1 15.1-1.3l46.9 20a16.3 16.3 0 0 1 9.6 16.7A56.2 56.2 0 0 1 176 224ZM82.9 40.3A40 40 0 0 0 48 80a128.1 128.1 0 0 0 128 128a40 40 0 0 0 39.7-34.9l-46.9-20l-25 16.7a16 16 0 0 1-15.7 1.1a92.5 92.5 0 0 1-42.8-42.6a16 16 0 0 1 1-15.7L103 87.2ZM135 156.5Z" />
                                </svg>
                                <div class="me-3">
                                    <a href="tel:0224148948" class="d-block">0224148948 </a>
                                    <a href="tel:01111909869" class="d-block">01111909869 </a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-10">
                                <svg width="32" height="32" viewBox="0 0 256 256">
                                    <path fill="var(--color2)"
                                          d="M128.1 64a40 40 0 1 0 40 40a40.1 40.1 0 0 0-40-40Zm0 64a24 24 0 1 1 24-24a24.1 24.1 0 0 1-24 24Zm0-112a88.1 88.1 0 0 0-88 88c0 31.4 14.5 64.7 42 96.2a259.4 259.4 0 0 0 41.4 38.4a8.3 8.3 0 0 0 9.2 0a257.6 257.6 0 0 0 41.5-38.4c27.4-31.5 41.9-64.8 41.9-96.2a88.1 88.1 0 0 0-88-88Zm0 206c-16.5-13-72-60.8-72-118a72 72 0 0 1 144 0c0 57.2-55.5 105-72 118Z" />
                                </svg>
                                <div class="me-3">
                                    <a href="https://goo.gl/maps/RU13EbdTVZ435PLm6" target="_blank" class="d-block">11 Abd El-hady sadik st, <br> Heliopolis,Cairo,Egypt</a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-10">
                                <svg width="32" height="32" viewBox="0 0 256 256">
                                    <path fill="var(--color2)"
                                          d="M224 48H32a8 8 0 0 0-8 8v136a16 16 0 0 0 16 16h176a16 16 0 0 0 16-16V56a8 8 0 0 0-8-8Zm-20.6 16L128 133.1L52.6 64ZM216 192H40V74.2l82.6 75.7a8 8 0 0 0 10.8 0L216 74.2V192Z" />
                                </svg>
                                <div class="me-3">
                                    <a href="mailto:Info@edudigit.net" class="d-block">Info@edudigit.net </a>
                                    <a href="mailto:sales@edudigit.net" class="d-block">sales@edudigit.net </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-4">
                <div class="copyrights">
                    <span> Powered by</span> <a href="#" target="_blank"><img src="./assets/images/uktralogo.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<button class="to-top">
    <img src="./assets/images/scroll.gif" alt="">
</button>
<script src="./assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/particles.min.js"></script>
<script src="./assets/js/main.js"></script>
</body>

</html>
<?php /**PATH F:\edu_digit\resources\views/welcome.blade.php ENDPATH**/ ?>