<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/x-icon" href="./assets/images/fav.png">
    <title>Edu Digit</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="./assets/css/style-rtl.css">
    <link rel="stylesheet" href="./assets/css/responsive.css">
    <style>

        .hero-section{
            background-image: url('./assets/images/background.png');
            background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
        }

        .hero-h1{
            margin: auto;
            margin: 0px 8%;
        }

    </style>
</head>

<body>
<div class="loader" id="loader">
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
</div>
<nav>
    <div class="container">
        <div class="row">
            <div class="col-4 col-md-6 col-lg-4"> <a href="<?php echo e(route('home')); ?>"><img src="./assets/images/edulogo-1.png" alt="img" class="logo"></a></div>
            <div class="col-md-6 col-lg-4 d-none d-lg-block">
                <div class="d-flex h-100 justify-content-evenly align-items-center">
                    <a href="#hero">الرئيسية</a>
                    <a href="#about"> من نحن </a>
                    <a href="#module">النظام</a>
                    <a href="#footer">تواصل معنا</a>
                </div>
            </div>
            <div class="col-8 col-md-6 col-lg-4">
                <div class="d-flex justify-content-end align-items-center h-100 gap-20">
                    <a href="<?php echo e(url()->current()); ?>?change_language=en" class="d-flex align-items-center gap-10"><img src="./assets/images/usa.svg" alt="img" class="width-30"> EN </a>
                    <a href="#appointment" class="btn-style-2 "> حجز موعد <svg width="22" viewBox="0 0 256 256">
                            <path fill="currentColor" d="m221.7 133.7l-72 72a8.2 8.2 0 0 1-11.4 0a8.1 8.1 0 0 1 0-11.4l58.4-58.3H40a8 8 0 0 1 0-16h156.7l-58.4-58.3a8.1 8.1 0 0 1 11.4-11.4l72 72a8.1 8.1 0 0 1 0 11.4Z" />
                        </svg></a>
                </div>
            </div>
        </div>
    </div>
</nav>
<main>
    <div class="hero-section" id="hero" style="">
        <div id="particles" class="particles"></div>
        
        
        
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="text-center hero-h1"> one  automated  smart  solution</h1>
                    <br>
                    <a href="#appointment" class="btn-style-1 ">طلب موعد</a>
                </div>
                
                
                
            </div>
        </div>
    </div>

    <div class="about" id="about">
        <span class="stroke-text">why</span>
        <div class="container">
            <div class="row">
                <div class="col-md-6 z-10">
                    <h2 class="text-white">أفضل شريك نجاح</h2>
                    <p>نحن نتفهم بعمق سوق المدارس بالمهارات التحليلية لخبرائنا ، الذين يدرسون جميع رؤى السوق لنقدم لك النظام الأكثر فاعلية الذي يلبي ما تحتاجه بالضبط لتحقيق هدفك ، يدعمك Edu-digit في التخطيط والتنفيذ. خطوة إضافية معك من خلال الصيانة والاستشارات المهنية</p>
                    <p>
                        نحن لا نقدم فقط النظام الذي تتوقعه ، بل نقدم لمدرستك النظام الذي تحتاجه والذي يغطي كل التفاصيل ، فنحن نسهل كل عملية ونعزز أداء المدرسة بشكل عام
                    </p>
                </div>
                <div class="col-md-6">
                    <ul class="about-list">
                        <li>خطط التسعير الأكثر منطقية.</li>
                        <li>النظام الأكثر فعالية من حيث التكلفة.</li>
                        <li>عرض اجتماع للتوضيح</li>
                        <li>مميزات ووظائف النظام</li>
                        <li>تدريب على الأرض لمساعدة طاقمك على العمل بفعالية</li>
                        <li>صيانة مخصصة لحل أي مشاكل محتملة</li>
                        <li>نصائح لمواكبة احتياجات السوق</li>
                        <li>وجهة نظر الخبراء لمساعدتك على اتخاذ قرارات مهمة</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="modules" id="module">
        <div id="particles2" class="particles"></div>
        <div class="container">
            <div class="col-12 mb-5">
                <h2>system modules</h2>
                <div class="col-md-6 col-lg-4">
                    <p>وحدات نظام إدارة المدرسة و وظائفها بنظام واحد ، وإدارة مدرسية سريعة وذكية </p>
                </div>
            </div>
            <div class="row g-3 g-md-4">
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Front Office.svg" alt="">
                        <h5>قسم الإستقبال</h5>
                        <p>للاستفسارات والمكالمات والزوار واستلام البريد والإرسال</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Student Affairs.svg" alt="">
                        <h5>شؤون الطلاب</h5>
                        <p>للحصول على معلومات مثل الملف الشخصي للطالب والقبول والتاريخ والحضور وتقرير الحضور</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Fees Collection.svg" alt="">
                        <h5>تحصيل المصاريف</h5>
                        <p>لجميع التفاصيل المتعلقة بتحصيل رسوم الطلاب ، وإنشاء ماجستير الرسوم ، وتقرير الرسوم والمستحقات</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Finance.svg" alt="">
                        <h5>الحسابات</h5>
                        <p>للدخل والمصروفات والخدمات المصرفية والإدارة الآمنة ودفتر الأستاذ العام وتقارير الأرباح والخسائر</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Examinations.svg" alt="">
                        <h5>الامتحانات</h5>
                        <p>لإنشاء الامتحانات وجدولة الامتحان ودخول علامات الاختبار وعلامات الدرجات</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Material Hub.svg" alt="">
                        <h5>مركز الوسائط و المواد الدراسيه </h5>
                        <p>لإدارة حالة الموضوع وخطة الدرس ومواد دراسة الواجبات</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Online Portal.svg" alt="">
                        <h5>البوابة الإلكترونية</h5>
                        <p>للامتحانات عبر الإنترنت ، فصول Zoom Live G-Meet الحية للطلاب</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Academics.svg" alt="">
                        <h5>القسم الأكاديمي</h5>
                        <p>بالنسبة للفصول الدراسية والمواد الدراسية ، قم بتعيين المعلمين والجدول الزمني وترقية الطلاب إلى الفصل العلوي.</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Human Resource.svg" alt="">
                        <h5>الموارد البشرية</h5>
                        <p>لإدارة أعضاء هيئة التدريس: البحث ، الملف الشخصي ، الحضور ، كشوف المرتبات والإجازات</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Communicate.svg" alt="">
                        <h5>التواصل</h5>
                        <p>لوحة الملاحظات مع نظام المراسلة للطلاب وأولياء الأمور والمعلمين</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Library.svg" alt="">
                        <h5>المكتبة</h5>
                        <p>يمكن إدارة جميع الكتب الموجودة في مكتبتك هنا</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Inventory.svg" alt="">
                        <h5>المخازن</h5>
                        <p>إدارة جميع أصول مدرستك بالمخزون وتخزينها في وحدة الجرد</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Transport.svg" alt="">
                        <h5>المواصلات</h5>
                        <p>لإدارة خدمات النقل مثل الطرق وأجورها</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Hostel.svg" alt="">
                        <h5>التسكين</h5>
                        <p>لإدارة النزل وغرف النزل وأسعارها</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Certificate.svg" alt="">
                        <h5>شهادات</h5>
                        <p>تصميم وإنشاء شهادة الطالب وبطاقة الهوية هنا</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Front CMS.svg" alt="">
                        <h5>موقع المدرسه</h5>
                        <p>إدارة الموقع: إنشاء صفحات وقوائم وأحداث ومعرض وأخبار</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Reports.svg" alt="">
                        <h5>التقارير</h5>
                        <p>يمكن العثور هنا على جميع التقارير المختلفة المتعلقة بوحدات مختلفة</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/System Settings.svg" alt="">
                        <h5>اعدادات النظام</h5>
                        <p>التكوين مثل الجلسات المدرسية والدفع والنسخ الاحتياطي واللغات والحقول المخصصة</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Calendar & to-do List.svg" alt="">
                        <h5>التقويم</h5>
                        <p>تتبع الأنشطة الدورية وإدارتها وإنشاء مهمة في قائمة المهام</p>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="box-icon">
                        <img src="./assets/images/icons/Chat.svg" alt="">
                        <h5>المحادثات</h5>
                        <p>الدردشة للموظفين والطلاب في اتجاهين</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="appointment" id="appointment">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 text-white text-center">
                    <h2 class="text-white">طلب موعد</h2>
                    <p>أرسل بيانات التواصل الخاصة بك أدناه،سيتم التواصل معك في أسرع وقت.</p>
                </div>
                <div class="col-md-8 col-lg-6">
                    <form method="post" action="<?php echo e(route('store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">الاسم *</label>
                                    <input type="text" name="name" placeholder="الاسم" id="" required>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">البريد الإلكتروني</label>
                                    <input type="email" name="email" placeholder="البريد الإلكتروني" id="">
                                    <?php if($errors->has('email')): ?>
                                        <p style="color:red;" class="error"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">رقم الهاتف  *</label>
                                    <input type="text" name="phone" placeholder="رقم الهاتف" id="" required>
                                    <?php if($errors->has('phone')): ?>
                                        <p style="color:red;" class="error"><?php echo e($errors->first('phone')); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">المحافظة </label>
                                    <select name="government" id="">
                                        <option value="">اختار</option>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city['governorate_name_en']); ?>"><?php echo e($city['governorate_name_en']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">الوظيفة </label>
                                    <input name="position" type="text" placeholder="الوظيفة" id="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">إسم المدرسة</label>
                                    <input name="school_name" type="text" placeholder="إسم المدرسة" id="">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="">كيف سمعت عنا</label>
                                    <select name="how_you_heard_about_us" id="">
                                        <option value="">اختار</option>
                                        <option value="Google Search">جوجل</option>
                                        <option value="Facebook">فيسبوك</option>
                                        <option value="Instagram">انستجرام</option>
                                        <option value="Youtube">يوتيوب</option>
                                        <option value="Recommended by Friends">ترشيح من الاصدقاء</option>
                                        <option value="Others">اخري</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit">إرسال</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<footer id="footer">
    <div class="container">
        <div class="row justify-content-center">
            <div class=" col-lg-10">
                <div class="footer-content">
                    <img src="./assets/images/edulogo-2.png" alt="logo" class="footer-logo">
                    <div>
                        <h5 class="mb-4 mt-3 mt-md-0">تواصل معنا</h5>
                        <div class="d-flex align-items-center gap-20 flex-wrap">
                            <div class="d-flex align-items-center gap-10">
                                <svg width="32" height="32" viewBox="0 0 256 256">
                                    <path fill="var(--color2)"
                                          d="M176 224C96.6 224 32 159.4 32 80a56.2 56.2 0 0 1 48.9-55.6A16.3 16.3 0 0 1 97.6 34l20.1 46.9a15.9 15.9 0 0 1-1.4 15.1l-16.6 25.4a76.5 76.5 0 0 0 35.2 35l25.1-16.7a15.6 15.6 0 0 1 15.1-1.3l46.9 20a16.3 16.3 0 0 1 9.6 16.7A56.2 56.2 0 0 1 176 224ZM82.9 40.3A40 40 0 0 0 48 80a128.1 128.1 0 0 0 128 128a40 40 0 0 0 39.7-34.9l-46.9-20l-25 16.7a16 16 0 0 1-15.7 1.1a92.5 92.5 0 0 1-42.8-42.6a16 16 0 0 1 1-15.7L103 87.2ZM135 156.5Z" />
                                </svg>
                                <div class="me-3">
                                    <a href="tel:0224148948" class="d-block">0224148948 </a>
                                    <a href="tel:01111909869" class="d-block">01111909869 </a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-10">
                                <svg width="32" height="32" viewBox="0 0 256 256">
                                    <path fill="var(--color2)"
                                          d="M128.1 64a40 40 0 1 0 40 40a40.1 40.1 0 0 0-40-40Zm0 64a24 24 0 1 1 24-24a24.1 24.1 0 0 1-24 24Zm0-112a88.1 88.1 0 0 0-88 88c0 31.4 14.5 64.7 42 96.2a259.4 259.4 0 0 0 41.4 38.4a8.3 8.3 0 0 0 9.2 0a257.6 257.6 0 0 0 41.5-38.4c27.4-31.5 41.9-64.8 41.9-96.2a88.1 88.1 0 0 0-88-88Zm0 206c-16.5-13-72-60.8-72-118a72 72 0 0 1 144 0c0 57.2-55.5 105-72 118Z" />
                                </svg>
                                <div class="me-3">
                                    <a href="https://goo.gl/maps/RU13EbdTVZ435PLm6" target="_blank" class="d-block">
                                        11 شارع عبدالهادي صادق, <br>هيليوبليس, القاهرة, مصر </a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-10">
                                <svg width="32" height="32" viewBox="0 0 256 256">
                                    <path fill="var(--color2)"
                                          d="M224 48H32a8 8 0 0 0-8 8v136a16 16 0 0 0 16 16h176a16 16 0 0 0 16-16V56a8 8 0 0 0-8-8Zm-20.6 16L128 133.1L52.6 64ZM216 192H40V74.2l82.6 75.7a8 8 0 0 0 10.8 0L216 74.2V192Z" />
                                </svg>
                                <div class="me-3">
                                    <a href="mailto:Info@edudigit.net" class="d-block">Info@edudigit.net </a>
                                    <a href="mailto:sales@edudigit.net" class="d-block">sales@edudigit.net </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-4">
                <div class="copyrights">
                    <span> powered by</span> <a href="#" target="_blank"><img src="./assets/images/uktralogo.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<button class="to-top">
    <img src="./assets/images/scroll.gif" alt="">
</button>
<script src="./assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/particles.min.js"></script>
<script src="./assets/js/main.js"></script>
</body>

</html>
<?php /**PATH F:\edu_digit\resources\views/welcome_ar.blade.php ENDPATH**/ ?>